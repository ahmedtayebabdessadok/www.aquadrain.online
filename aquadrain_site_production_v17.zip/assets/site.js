
(() => {
  const LEGACY = {"?page=blog": "/guides-debouchage-assainissement/", "?page=local": "/zones-intervention-debouchage/", "?page=clients": "/solutions-clients-debouchage-assainissement/", "?page=service": "/services-debouchage-assainissement/", "?page=about": "/a-propos-aquadrain-service/", "?page=partners": "/presse-partenaires-aquadrain/", "?page=blog&post=locataire-ou-proprietaire": "/guide/canalisation-bouchee-locataire-proprietaire/", "?page=blog&post=prix-debouchage-haute-pression": "/guide/prix-debouchage-haute-pression-hydrocurage/", "?page=blog&post=wc-eau-remonte": "/guide/wc-bouche-eau-remonte/", "?page=blog&post=passage-camera-tarif": "/guide/prix-inspection-camera-canalisation/", "?page=blog&post=choisir-societe-debouchage": "/guide/choisir-societe-debouchage-canalisation/", "?page=blog&post=debouchage-val-de-marne": "/guide/debouchage-canalisation-val-de-marne-94/", "?page=blog&post=pompage-fosse-septique-prix": "/guide/prix-pompage-vidange-fosse-septique/", "?page=blog&post=vidange-fosse-septique-77": "/guide/vidange-fosse-septique-seine-et-marne-77/", "?page=blog&post=vidange-fosse-septique-91": "/guide/vidange-fosse-septique-essonne-91/", "?page=blog&post=odeur-canalisation-remontee": "/guide/odeur-canalisation-remontee/", "?page=blog&post=fosse-septique-pleine-frequence": "/guide/fosse-septique-pleine-frequence-vidange/", "?page=blog&post=prix-debouchage-canalisation-2026": "/guide/prix-debouchage-canalisation-2026/", "?page=blog&post=bouchon-graisse-canalisation": "/guide/bouchon-graisse-canalisation/", "?page=blog&post=curage-canalisation-curatif-preventif": "/guide/curage-canalisation-curatif-preventif/", "?page=blog&post=canalisation-cassee-chemisage-reparation": "/guide/canalisation-cassee-chemisage-reparation/", "?page=local&zone=saint-maur-des-fosses": "/debouchage-canalisation-saint-maur-des-fosses/", "?page=local&zone=creteil": "/debouchage-canalisation-creteil/", "?page=local&zone=vincennes": "/debouchage-canalisation-vincennes/", "?page=local&zone=maisons-alfort": "/debouchage-canalisation-maisons-alfort/", "?page=local&zone=champigny-sur-marne": "/debouchage-canalisation-champigny-sur-marne/", "?page=local&zone=fontenay-sous-bois": "/debouchage-canalisation-fontenay-sous-bois/", "?page=local&zone=nogent-sur-marne": "/debouchage-canalisation-nogent-sur-marne/", "?page=local&zone=vidange-fosse-septique-94": "/vidange-fosse-septique-val-de-marne-94/", "?page=local&zone=paris-1": "/debouchage-canalisation-paris-1/", "?page=local&zone=paris-2": "/debouchage-canalisation-paris-2/", "?page=local&zone=paris-3": "/debouchage-canalisation-paris-3/", "?page=local&zone=paris-4": "/debouchage-canalisation-paris-4/", "?page=local&zone=paris-5": "/debouchage-canalisation-paris-5/", "?page=local&zone=paris-6": "/debouchage-canalisation-paris-6/", "?page=local&zone=paris-7": "/debouchage-canalisation-paris-7/", "?page=local&zone=paris-8": "/debouchage-canalisation-paris-8/", "?page=local&zone=paris-9": "/debouchage-canalisation-paris-9/", "?page=local&zone=paris-10": "/debouchage-canalisation-paris-10/", "?page=local&zone=paris-11": "/debouchage-canalisation-paris-11/", "?page=local&zone=paris-12": "/debouchage-canalisation-paris-12/", "?page=local&zone=paris-13": "/debouchage-canalisation-paris-13/", "?page=local&zone=paris-14": "/debouchage-canalisation-paris-14/", "?page=local&zone=paris-15": "/debouchage-canalisation-paris-15/", "?page=local&zone=paris-16": "/debouchage-canalisation-paris-16/", "?page=local&zone=paris-17": "/debouchage-canalisation-paris-17/", "?page=local&zone=paris-18": "/debouchage-canalisation-paris-18/", "?page=local&zone=paris-19": "/debouchage-canalisation-paris-19/", "?page=local&zone=paris-20": "/debouchage-canalisation-paris-20/", "?page=clients&profile=locataire": "/canalisation-bouchee-locataire/", "?page=clients&profile=proprietaire": "/debouchage-canalisation-proprietaire-bailleur/", "?page=clients&profile=syndic-bailleur": "/debouchage-canalisation-syndic-copropriete/", "?page=clients&profile=entreprise-commerce": "/debouchage-canalisation-entreprise-restaurant-commerce/", "?page=clients&profile=plombier-partenaire": "/partenaire-plombier-hydrocurage-camera/", "?page=clients&profile=assurance": "/assurance-debouchage-degat-des-eaux/", "?page=clients&profile=immobilier": "/inspection-canalisation-achat-immobilier/", "?page=service&name=debouchage-canalisation": "/debouchage-canalisation/", "?page=service&name=debouchage-wc": "/debouchage-wc/", "?page=service&name=egout-regard": "/debouchage-egout-regard/", "?page=service&name=evier-lavabo": "/debouchage-evier-lavabo/", "?page=service&name=douche-siphon": "/debouchage-douche-siphon/", "?page=service&name=salle-de-bains": "/debouchage-salle-de-bains-baignoire/", "?page=service&name=machine-a-laver": "/debouchage-evacuation-machine-a-laver/", "?page=service&name=lave-vaisselle": "/debouchage-evacuation-lave-vaisselle/", "?page=service&name=inspection-camera": "/inspection-camera-canalisation/", "?page=service&name=curage-hydrocurage": "/hydrocurage-curage-canalisation/", "?page=service&name=assainissement": "/assainissement-pompage-canalisation/", "?page=service&name=entretien-canalisations": "/entretien-curage-canalisations/", "?page=service&name=mauvaises-odeurs": "/mauvaises-odeurs-canalisation/"};
  if (location.pathname === '/' && location.search) {
    const target = LEGACY[location.search];
    if (target) { location.replace(target + location.hash); return; }
  }

  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver(es => es.forEach(e => {
      if (e.isIntersecting) e.target.classList.add('in');
    }), {threshold:.06});
    document.querySelectorAll('.reveal').forEach(e => io.observe(e));
  } else {
    document.querySelectorAll('.reveal').forEach(e => e.classList.add('in'));
  }

  document.querySelectorAll('.faq-q').forEach(b => b.addEventListener('click', () => {
    b.closest('.faq-item')?.classList.toggle('open');
  }));

  const tr = document.getElementById('reviewTrack');
  if (tr) {
    const sl = [...tr.children]; let i = 0;
    const sh = () => tr.style.transform = `translateX(-${i*100}%)`;
    const prev = document.getElementById('prevReview');
    const next = document.getElementById('nextReview');
    if (prev) prev.onclick = () => { i=(i-1+sl.length)%sl.length; sh(); };
    if (next) next.onclick = () => { i=(i+1)%sl.length; sh(); };
  }

  document.querySelectorAll('form#quoteForm').forEach(form => {
    const status = form.querySelector('.form-status');
    const btn = form.querySelector('button[type="submit"]');
    const endpoint = form.dataset.emailEndpoint;

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!form.reportValidity()) return;

      const original = btn?.dataset.defaultLabel || 'Envoyer ma demande';
      if (btn) { btn.disabled = true; btn.textContent = 'Envoi en cours…'; }
      if (status) { status.className='form-status'; status.textContent=''; }

      const fd = new FormData(form);
      fd.set('_url', location.href);
      const email = fd.get('email');
      if (email) fd.set('_replyto', email);

      const payload = Object.fromEntries(fd.entries());

      try {
        const response = await fetch(endpoint, {
          method:'POST',
          headers:{'Content-Type':'application/json','Accept':'application/json'},
          body:JSON.stringify(payload)
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok || data.success === false) throw new Error(data.message || 'Erreur d’envoi');

        form.reset();
        if (status) {
          status.className='form-status success';
          status.textContent='Votre demande a bien été transmise. AquaDrain Service vous recontactera dès que possible.';
        }
      } catch (err) {
        if (status) {
          status.className='form-status error';
          status.textContent='L’envoi direct a rencontré un problème. Une tentative de secours va être lancée.';
        }
        // Native POST fallback through FormSubmit.
        setTimeout(() => HTMLFormElement.prototype.submit.call(form), 600);
      } finally {
        if (btn) { btn.disabled = false; btn.textContent = original; }
      }
    });
  });
})();
