#!/usr/bin/env python3
from pathlib import Path
import sys

OLD = "https://www.aquadrain-service.fr"
if len(sys.argv) != 2:
    raise SystemExit("Usage: python3 set_domain.py https://www.votre-domaine.fr")
new = sys.argv[1].rstrip("/")
if not new.startswith(("http://","https://")):
    raise SystemExit("Le domaine doit commencer par https://")

root = Path(__file__).resolve().parent
extensions = {".html",".xml",".txt",".json",".js",".md"}
changed = 0
for p in root.rglob("*"):
    if p.is_file() and p.suffix.lower() in extensions and p.name != "set_domain.py":
        try:
            text = p.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        if OLD in text:
            p.write_text(text.replace(OLD, new), encoding="utf-8")
            changed += 1
print(f"Domaine remplacé dans {changed} fichiers : {new}")
