# AquaDrain Service — Pack production V17

## Ce qui est inclus

- URLs propres avec mots-clés (aucun `?page=...` dans le maillage interne)
- 72 URLs indexables dans `sitemap.xml`
- `robots.txt`
- page humaine `/plan-du-site/`
- page `404.html`
- formulaire de devis automatique via FormSubmit
- page de confirmation `/merci-demande-devis/`
- redirection des anciennes URLs `?page=...` vers les nouvelles URLs
- configuration Vercel (`vercel.json`) et Apache (`.htaccess`)
- CSS et JavaScript mutualisés dans `/assets/`

## Formulaire email

Le formulaire envoie les demandes à :
`ahmedtayebabdessadok@gmail.com`

Le service utilisé est FormSubmit.

### Activation obligatoire une seule fois

Après la **première soumission sur le site en ligne**, FormSubmit envoie un email d'activation à `ahmedtayebabdessadok@gmail.com`.
Cliquez sur le bouton/lien de confirmation dans cet email. Après cette activation, les nouvelles demandes du formulaire arrivent directement dans cette boîte mail.

Si l'email d'activation n'apparaît pas, vérifier les spams.

## Domaine

Le pack est préconfiguré avec :
`https://www.aquadrain-service.fr`

Si le domaine final est différent, lancer depuis le dossier du site :

```bash
python3 set_domain.py https://www.votre-domaine.fr
```

Cette commande met à jour les canonical, le sitemap, robots.txt, llms.txt et les URLs de redirection du formulaire.

## Déploiement

Uploader **le contenu du dossier**, pas le dossier parent lui-même.

Les fichiers `sitemap.xml` et `robots.txt` doivent se retrouver directement à la racine publique.

Après déploiement, tester :

- `https://www.aquadrain-service.fr/sitemap.xml`
- `https://www.aquadrain-service.fr/robots.txt`
- `https://www.aquadrain-service.fr/plan-du-site/`
- `https://www.aquadrain-service.fr/devis-debouchage-canalisation/`

Puis ajouter dans Google Search Console :

`https://www.aquadrain-service.fr/sitemap.xml`

## Important

Si votre vrai domaine n'est pas `https://www.aquadrain-service.fr`, exécutez `set_domain.py` AVANT de soumettre le sitemap à Google.
