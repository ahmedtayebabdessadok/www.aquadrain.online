AquaDrain — Déploiement Vercel

Contenu :
- index.html
- package.json
- vercel.json

Dans Vercel :
1. Framework Preset : Other
2. Build Command : laisser vide
3. Output Directory : laisser vide
4. Install Command : laisser vide
5. Root Directory : dossier contenant index.html

Puis Redeploy.
