# AquaDrain Service — Pack production V17

## Ce qui est inclus

- URLs propres avec mots-clés (aucun `?page=...` dans le maillage interne)
- 72 URLs indexables dans `sitemap.xml`
- `robots.txt`
- page humaine `/plan-du-site/`
- page `404.html`
- formulaire de devis automatique via FormSubmit
- page de confirmation `/merci-demande-devis/`
- redirection des anciennes URLs `?page=...` vers les nouvelles URLs
- configuration Vercel (`vercel.json`) et Apache (`.htaccess`)
- CSS et JavaScript mutualisés dans `/assets/`

## Formulaire email

Le formulaire envoie les demandes à :
`ahmedtayebabdessadok@gmail.com`

Le service utilisé est FormSubmit.

### Activation obligatoire une seule fois

Après la **première soumission sur le site en ligne**, FormSubmit envoie un email d'activation à `ahmedtayebabdessadok@gmail.com`.
Cliquez sur le bouton/lien de confirmation dans cet email. Après cette activation, les nouvelles demandes du formulaire arrivent directement dans cette boîte mail.

Si l'email d'activation n'apparaît pas, vérifier les spams.

## Domaine

Le pack est préconfiguré avec :
`https://www.aquadrain-service.fr`

Si le domaine final est différent, lancer depuis le dossier du site :

```bash
python3 set_domain.py https://www.votre-domaine.fr
```

Cette commande met à jour les canonical, le sitemap, robots.txt, llms.txt et les URLs de redirection du formulaire.

## Déploiement

Uploader **le contenu du dossier**, pas le dossier parent lui-même.

Les fichiers `sitemap.xml` et `robots.txt` doivent se retrouver directement à la racine publique.

Après déploiement, tester :

- `https://www.aquadrain-service.fr/sitemap.xml`
- `https://www.aquadrain-service.fr/robots.txt`
- `https://www.aquadrain-service.fr/plan-du-site/`
- `https://www.aquadrain-service.fr/devis-debouchage-canalisation/`

Puis ajouter dans Google Search Console :

`https://www.aquadrain-service.fr/sitemap.xml`

## Important

Si votre vrai domaine n'est pas `https://www.aquadrain-service.fr`, exécutez `set_domain.py` AVANT de soumettre le sitemap à Google.


## Nouveau fonctionnement du formulaire V18

Le formulaire fonctionne maintenant en **2 étapes** :

1. Le client remplit sa demande puis clique sur **« Préparer ma demande »**.
2. Un récapitulatif apparaît avec le service, l’urgence, le nom, le téléphone, l’email, l’adresse et le problème.
3. Le client peut cliquer sur **« Modifier ma demande »** s’il veut corriger une information.
4. Il clique ensuite sur **« Envoyer ma demande »**.
5. La demande est alors transmise directement à `ahmedtayebabdessadok@gmail.com` via FormSubmit, sans ouvrir Gmail ou Outlook chez le client.

L’activation FormSubmit reste nécessaire une seule fois après la première soumission sur le site en ligne.
